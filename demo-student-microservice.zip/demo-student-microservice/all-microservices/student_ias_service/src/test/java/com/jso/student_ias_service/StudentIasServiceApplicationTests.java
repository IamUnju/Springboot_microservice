package com.jso.student_ias_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentIasServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
