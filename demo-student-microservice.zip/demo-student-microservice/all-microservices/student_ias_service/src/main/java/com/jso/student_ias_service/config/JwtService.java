package com.jso.student_ias_service.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
@RequiredArgsConstructor
public class JwtService {

    private final JwtProperties jwtProperties;

    // --- CLAIM EXTRACTION ---

    public String extractSchoolId(String token) {
        return extractClaim(token, claims -> claims.get("schoolId", String.class));
    }

    public String extractUserId(String token) {
        // Change: Extracting userId as String to match your cross-service logic
        return extractClaim(token, claims -> claims.get("userId", String.class));
    }

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // --- TOKEN GENERATION ---

    public String generateAccessToken(UserDetails userDetails) {
        Map<String, Object> extraClaims = new HashMap<>();

        if (userDetails instanceof SecurityStudent securityStudent) {
            // FIX: Ensure we use the String ID (Username or Reg Number) for cross-service consistency
            extraClaims.put("userId", securityStudent.getUsername());
            extraClaims.put("schoolId", securityStudent.getSchoolId());

            // 403 FIX: Change key from "authorities" to "roles" to match Fee Service SecurityConfig
            extraClaims.put("roles", securityStudent.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .toList());
        }

        return buildToken(extraClaims, userDetails, jwtProperties.getExpiration());
    }

    public String generateRefreshToken(UserDetails userDetails) {
        Map<String, Object> extraClaims = new HashMap<>();

        if (userDetails instanceof SecurityStudent securityStudent) {
            // Keep refresh tokens light but consistent
            extraClaims.put("userId", securityStudent.getUsername());
            extraClaims.put("schoolId", securityStudent.getSchoolId());
        }

        return buildToken(extraClaims, userDetails, jwtProperties.getRefreshExpiration());
    }

    private String buildToken(Map<String, Object> extraClaims, UserDetails userDetails, long expiration) {
        return Jwts.builder()
                .header()
                .add("typ", "JWT")
                .add("alg", "RS256")
                .keyId("jso-student-key-01")
                .and()
                .claims(extraClaims)
                .subject(userDetails.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + expiration))
                .issuer("jso-student-management-service")
                .signWith(getPrivateKey(), Jwts.SIG.RS256)
                .compact();
    }

    // --- VALIDATION ---

    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getPublicKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    // --- KEY MANAGEMENT (CLASSPATH BASED) ---

    private PrivateKey getPrivateKey() {
        try {
            // 1. Load the file from the classpath using the property value
            // We strip "classpath:" because ClassPathResource looks in the resources root by default
            String path = jwtProperties.getPrivateKey().replace("classpath:", "");
            ClassPathResource resource = new ClassPathResource(path);

            byte[] keyBytes = resource.getInputStream().readAllBytes();
            String privateKeyPEM = new String(keyBytes)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s", ""); // Removes all newlines and spaces

            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyPEM));
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePrivate(keySpec);
        } catch (Exception e) {
            throw new RuntimeException("CRITICAL: Failed to load Private Key for Token Signing. " +
                    "Ensure file exists at " + jwtProperties.getPrivateKey(), e);
        }
    }

    public PublicKey getPublicKey() {
        try {
            // 2. Load the public key similarly
            String path = jwtProperties.getPublicKey().replace("classpath:", "");
            ClassPathResource resource = new ClassPathResource(path);

            byte[] keyBytes = resource.getInputStream().readAllBytes();
            String publicKeyPEM = new String(keyBytes)
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "")
                    .replaceAll("\\s", "");

            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyPEM));
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePublic(keySpec);
        } catch (Exception e) {
            throw new RuntimeException("CRITICAL: Failed to load Public Key from classpath", e);
        }
    }
}