package com.jso.student_ias_service.repo;

import com.jso.student_ias_service.entities.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.List;

public interface PermissionRepository extends JpaRepository<Permission, Long> {

    // Fetch all permissions for the logged-in school
    List<Permission> findAllBySchoolId(String schoolId);

    // Find a specific permission by name within the school context
    Optional<Permission> findByNameAndSchoolId(String name, String schoolId);
}