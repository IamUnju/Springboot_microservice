package com.jso.student_ias_service.entities;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "student_security_details")
@Getter @Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class StudentSecurity extends BaseSchoolEntity {

    @Id
    @Column(name = "student_id")
    private Long id;

    @OneToOne
    @MapsId
    @JoinColumn(name = "student_id")
    private Student student;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Builder.Default
    @Column(nullable = false)
    private boolean accountNonLocked = true;

    @Builder.Default
    @Column(nullable = false)
    private boolean accountNonExpired = true;

    @Builder.Default
    @Column(nullable = false)
    private boolean credentialsNonExpired = true;

    @Builder.Default
    @Column(name = "failed_attempts", nullable = false)
    private int failedAttempts = 0;

    @Column(name = "lock_time")
    private Instant lockTime;

    @Column(name = "last_login_at")
    private Instant lastLoginAt;

    @Column(name = "password_reset_token")
    private String passwordResetToken; // Student reset token (usually simpler for portal access)

    @Column(name = "password_reset_expiry")
    private Instant passwordResetExpiry;

    // =========================================================================
    // Security Logic Methods
    // =========================================================================

    /**
     * Generates a 30-minute reset token for the Student Portal.
     */
    public String generateResetToken() {
        String rawToken = UUID.randomUUID().toString();
        this.passwordResetToken = rawToken;
        this.passwordResetExpiry = Instant.now().plusSeconds(1800); // 30 minutes
        return rawToken;
    }

    /**
     * Validates if the provided token matches and is within the school's expiry policy.
     */
    public boolean matchesResetToken(String token) {
        return this.passwordResetToken != null &&
                this.passwordResetToken.equals(token) &&
                this.passwordResetExpiry != null &&
                Instant.now().isBefore(this.passwordResetExpiry);
    }

    /**
     * Clears reset metadata after the student successfully updates their password.
     */
    public void clearResetToken() {
        this.passwordResetToken = null;
        this.passwordResetExpiry = null;
    }

    /**
     * Resets failed attempts and records timestamp on successful portal login.
     */
    public void recordSuccessfulLogin() {
        this.failedAttempts = 0;
        this.lockTime = null;
        this.lastLoginAt = Instant.now();
    }
}