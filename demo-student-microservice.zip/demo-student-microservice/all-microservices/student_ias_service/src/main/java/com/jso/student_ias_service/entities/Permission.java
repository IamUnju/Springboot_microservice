package com.jso.student_ias_service.entities;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Table(
        name = "permissions",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_permission_name_school",
                columnNames = {"name", "school_id"} // Isolated per school
        ),
        indexes = {
                @Index(name = "idx_permission_name", columnList = "name")
        }
)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Permission extends BaseSchoolEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name; // e.g., "student:read", "student:update-profile"

    @Column(length = 255)
    private String description;

    @Version
    @Column(name = "version")
    private Long version;

    /**
     * Helper to check if a permission is active.
     * You can add logic here if you add an 'active' boolean later.
     */
    public String getFullPermissionName() {
        return name;
    }
}