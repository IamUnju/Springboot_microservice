package com.jso.student_ias_service.config;

import com.jso.student_ias_service.entities.EnrollmentStatus;
import com.jso.student_ias_service.entities.Student;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiredArgsConstructor
public class SecurityStudent implements UserDetails {

    private final Student student;

    // --- Identity Methods (From Student Entity) ---

    public String getStudentId() {
        return String.valueOf(student.getId());
    }

    public EnrollmentStatus getStatus() {
        return student.getStatus();
    }

    @Override
    public String getUsername() {
        // In this service, username is the Registration Number
        return student.getUsername();
    }

    /**
     * Replaces getTenantId() to match the String identifier approach
     * used in the Resource Server.
     */
    public String getSchoolId() {
        return student.getSchoolId();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (student.getRoles() == null) {
            return Collections.emptySet();
        }

        return student.getRoles().stream()
                .flatMap(role -> {
                    // Combine Role Name (e.g., ROLE_STUDENT)
                    Stream<SimpleGrantedAuthority> roleAuthority = Stream.of(new SimpleGrantedAuthority(role.getName()));

                    // With granular Permissions (e.g., student:read)
                    Stream<SimpleGrantedAuthority> permissionAuthorities = (role.getPermissions() != null)
                            ? role.getPermissions().stream().map(p -> new SimpleGrantedAuthority(p.getName()))
                            : Stream.empty();

                    return Stream.concat(roleAuthority, permissionAuthorities);
                })
                .collect(Collectors.toSet());
    }

    // --- Security & Credential Methods (Delegated to StudentSecurity) ---

    @Override
    public String getPassword() {
        return student.getSecurity().getPasswordHash();
    }

    @Override
    public boolean isAccountNonExpired() {
        return student.getSecurity().isAccountNonExpired();
    }

    @Override
    public boolean isAccountNonLocked() {
        return student.getSecurity().isAccountNonLocked();
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return student.getSecurity().isCredentialsNonExpired();
    }

    @Override
    public boolean isEnabled() {
        // A student is enabled if their enrollment status is ACTIVE
        return student.getStatus() == EnrollmentStatus.ACTIVE &&
                student.getSecurity().isAccountNonLocked() &&
                student.getSecurity().isAccountNonExpired();
    }
}