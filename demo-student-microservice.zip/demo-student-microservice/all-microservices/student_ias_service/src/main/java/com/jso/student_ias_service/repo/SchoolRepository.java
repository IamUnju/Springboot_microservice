package com.jso.student_ias_service.repo;

import com.jso.student_ias_service.entities.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {
    Optional<School> findBySchoolIdentifier(String schoolIdentifier);
    boolean existsBySchoolIdentifierAndActiveTrue(String schoolIdentifier);
    @Query("SELECT s.name FROM School s WHERE s.schoolIdentifier = :identifier")
    Optional<String> findSchoolNameByIdentifier(@Param("identifier") String identifier);
}