package com.jso.student_ias_service.controller;

import com.jso.student_ias_service.dtos.*;
import com.jso.student_ias_service.services.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;


    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<AuthResponse> refreshToken(@RequestHeader("Authorization") String authHeader) {
        // Extract token from "Bearer <token>"
        String token = authHeader.startsWith("Bearer ") ? authHeader.substring(7) : authHeader;
        return ResponseEntity.ok(authService.refreshToken(token));
    }

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        authService.changePassword(request.oldPassword(), request.newPassword());
        return ResponseEntity.ok("Password updated successfully.");
    }

    @PostMapping("/password-reset/initiate")
    public ResponseEntity<String> initiateReset(@RequestParam String email) {
        String token = authService.initiatePasswordReset(email);
        // In production, this token is sent via email.
        log.info("Reset token generated: {}", token);
        return ResponseEntity.ok("If an account exists, reset instructions have been sent to your email.");
    }


    @PostMapping("/password-reset/confirm")
    public ResponseEntity<String> confirmReset(@Valid @RequestBody PasswordResetConfirmRequest request) {
        authService.resetPassword(request.token(), request.newPassword());
        return ResponseEntity.ok("Your password has been reset successfully.");
    }
}