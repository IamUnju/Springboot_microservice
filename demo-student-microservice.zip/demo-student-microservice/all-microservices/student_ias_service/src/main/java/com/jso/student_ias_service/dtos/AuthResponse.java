package com.jso.student_ias_service.dtos;

import lombok.Builder;
import java.util.List;

@Builder
public record AuthResponse(
        String accessToken,
        String refreshToken,
        String username,
        String userId,           // Database Primary Key for easier frontend API calls
        String schoolIdentifier, // The 'schoolId' string
        String status,           // e.g., ACTIVE, SUSPENDED
        List<String> roles       // Permissions and Roles for UI-based authorization
) {}