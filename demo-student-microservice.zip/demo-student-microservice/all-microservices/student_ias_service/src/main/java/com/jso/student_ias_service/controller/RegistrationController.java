package com.jso.student_ias_service.controller;

import com.jso.student_ias_service.dtos.RegisterRequest;
import com.jso.student_ias_service.services.RegistrationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class RegistrationController {

    private final RegistrationService registrationService;

    @PostMapping("/register")
    @PreAuthorize("hasAuthority('SCOPE_student:read')")
    public ResponseEntity<String> register(@Valid @RequestBody RegisterRequest request) {
        registrationService.registerStudent(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Student registration successful. You can now log in to your portal.");
    }
}