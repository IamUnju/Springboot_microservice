package com.jso.student_ias_service.config;

import com.jso.student_ias_service.entities.SchoolContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final CustomUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        try {
            // 1. Capture client IP for auditing/logging in SchoolContext
            String clientIp = getClientIp(request);
            SchoolContext.setClientIp(clientIp);

            final String authHeader = request.getHeader("Authorization");

            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                final String jwt = authHeader.substring(7).trim();

                // 2. Extract Identity & School Identifier from the JWT
                final String username = jwtService.extractUsername(jwt);
                final String schoolId = jwtService.extractSchoolId(jwt); // e.g. "arusha-primary-01"

                if (username != null && schoolId != null && SecurityContextHolder.getContext().getAuthentication() == null) {

                    // 3. Database-backed verification
                    // We load the student to verify they aren't locked/deactivated in THIS microservice
                    UserDetails userDetails = this.userDetailsService.loadUserByUsernameAndSchool(username, schoolId);

                    if (jwtService.isTokenValid(jwt, userDetails)) {
                        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                                userDetails,
                                null,
                                userDetails.getAuthorities()
                        );

                        authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                        SecurityContextHolder.getContext().setAuthentication(authToken);

                        // 4. Populate SchoolContext for JPA Auditing & BaseSchoolEntity
                        if (userDetails instanceof SecurityStudent securityStudent) {
                            SchoolContext.setSchoolId(securityStudent.getSchoolId()); // String ID
                            SchoolContext.setUserId(securityStudent.getStudentId());   // Database Primary Key
                        }
                    }
                }
            }

            filterChain.doFilter(request, response);

        } catch (Exception e) {
            log.error("JWT Authentication failed for request {}: {}", request.getRequestURI(), e.getMessage());
            filterChain.doFilter(request, response);
        } finally {
            // 5. CRITICAL: Clear context to prevent data leakage between threads
            SchoolContext.clear();
        }
    }

    private String getClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader != null && !xfHeader.isBlank()) {
            return xfHeader.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}