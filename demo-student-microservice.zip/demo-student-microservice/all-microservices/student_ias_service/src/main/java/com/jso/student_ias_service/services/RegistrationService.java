package com.jso.student_ias_service.services;


import com.jso.student_ias_service.dtos.RegisterRequest;
import com.jso.student_ias_service.entities.*;
import com.jso.student_ias_service.repo.RoleRepository;
import com.jso.student_ias_service.repo.SchoolRepository;
import com.jso.student_ias_service.repo.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrationService {

    private final StudentRepository studentRepository;
    private final SchoolRepository schoolRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * PUBLIC REGISTRATION (Self-Service)
     * Used when a student signs up via a portal. Assigns ROLE_STUDENT by default.
     */
    @Transactional
    public void registerStudent(RegisterRequest request) {
        validateUsernameUnique(request.username(), request.schoolIdentifier());

        // Fetch school to ensure it exists and is active
        School school = fetchSchool(request.schoolIdentifier());

        // Find default student role
        Role studentRole = roleRepository.findByNameAndSchoolId("ROLE_STUDENT", school.getSchoolIdentifier())
                .orElseThrow(() -> new RuntimeException("System Error: ROLE_STUDENT not configured for this school."));

        Student student = buildStudentWithSecurity(request, school, Set.of(studentRole));
        studentRepository.save(student);

        log.info("Student {} self-registered for school {}", request.username(), request.schoolIdentifier());
    }

    /**
     * ADMIN-LED REGISTRATION
     * Used by School Admins to create student accounts, staff accounts, or prefects.
     */
    @Transactional
    public void registerUserByAdmin(RegisterRequest request) {
        validateUsernameUnique(request.username(), request.schoolIdentifier());
        School school = fetchSchool(request.schoolIdentifier());

        if (request.roles() == null || request.roles().isEmpty()) {
            throw new RuntimeException("Admin must specify roles for the new account.");
        }

        // Prevent escalation: Common Admins cannot create Super Admins
        if (request.roles().contains("ROLE_SUPER_ADMIN")) {
            throw new RuntimeException("Unauthorized: Cannot assign SUPER_ADMIN privilege.");
        }

        Set<Role> assignedRoles = new HashSet<>(roleRepository.findAllByNameInAndSchoolId(request.roles(), school.getSchoolIdentifier()));

        Student student = buildStudentWithSecurity(request, school, assignedRoles);
        studentRepository.save(student);

        log.info("Admin created account {} for school {}", request.username(), request.schoolIdentifier());
    }

    /**
     * HIGH-LEVEL SYSTEM REGISTRATION
     * Used to create School Admins or Global System Admins.
     */
    @Transactional
    public void registerHighLevelAdmin(RegisterRequest request, String targetRole) {
        // 1. Validation Logic
        validateUsernameUnique(request.username(), request.schoolIdentifier());

        // 2. Context Loading
        School school = fetchSchool(request.schoolIdentifier());

        // 3. Role Resolution: Ensure the role is actually tied to the school in the DB
        Role adminRole = roleRepository.findByNameAndSchoolId(targetRole, school.getSchoolIdentifier())
                .orElseThrow(() -> new RuntimeException("Configuration Error: " + targetRole + " is not defined for " + school.getName()));

        // 4. Persistence
        Student adminAccount = buildStudentWithSecurity(request, school, Set.of(adminRole));
        studentRepository.save(adminAccount);

        log.info("Audit: [SUPER_ADMIN] created [{}] for user [{}] at school [{}]",
                targetRole, request.username(), request.schoolIdentifier());
    }

    // --- Private Helper Methods ---

    private void validateUsernameUnique(String username, String schoolId) {
        if (studentRepository.findByUsernameAndSchoolId(username, schoolId).isPresent()) {
            throw new RuntimeException("Registration Number/Username already exists in this school.");
        }
    }

    private School fetchSchool(String identifier) {
        return schoolRepository.findBySchoolIdentifier(identifier)
                .filter(School::isActive)
                .orElseThrow(() -> new RuntimeException("School not found or inactive: " + identifier));
    }

    /**
     * The "Professional Approach": Composition
     * Separates Academic Data (Student) from Credential Data (StudentSecurity).
     */
    private Student buildStudentWithSecurity(RegisterRequest request, School school, Set<Role> roles) {
        // 1. Create the Student Profile
        Student student = Student.builder()
                .username(request.username())
                .email(request.email())
                .fullName(request.fullName())
                .gradeLevel(request.gradeLevel())
                .schoolId(school.getSchoolIdentifier()) // From BaseSchoolEntity
                .roles(roles)
                .status(EnrollmentStatus.ACTIVE)
                .build();

        // 2. Create the Security Details
        StudentSecurity security = StudentSecurity.builder()
                .student(student) // Link to Student
                .schoolId(school.getSchoolIdentifier())
                .passwordHash(passwordEncoder.encode(request.password()))
                .accountNonLocked(true)
                .accountNonExpired(true)
                .credentialsNonExpired(true)
                .build();

        // 3. Establish the Bidirectional Link
        student.setSecurity(security);

        return student;
    }
}