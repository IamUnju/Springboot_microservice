package com.jso.student_ias_service.entities;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Table(
        name = "schools",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_school_identifier", columnNames = "school_identifier")
        },
        indexes = {
                @Index(name = "idx_school_active", columnList = "active"),
                @Index(name = "idx_school_identifier", columnList = "school_identifier")
        }
)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class School extends BaseSchoolEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // This matches the "schoolId" in your JWT and BaseSchoolEntity
    @Column(name = "school_identifier", nullable = false, updatable = false, length = 50)
    private String schoolIdentifier;

    @Column(nullable = false, length = 255)
    private String name;

    @Builder.Default
    @Column(nullable = false)
    private boolean active = true;

    // Specific to Student Management
    @Column(name = "school_type")
    private String schoolType; // e.g., Primary, Secondary, University

    @Column(name = "address")
    private String address;

    @Version
    private Long version;

    public void deactivate() {
        this.active = false;
    }

    public void activate() {
        this.active = true;
    }
}