package com.jso.student_ias_service.config;

import com.jso.student_ias_service.entities.Student;
import com.jso.student_ias_service.repo.StudentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final StudentRepository studentRepository;

    /**
     * Standard Spring Security method.
     * Supports "username@school_id" format for initial authentication.
     */
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String loginInput) throws UsernameNotFoundException {
        if (loginInput == null || !loginInput.contains("@")) {
            throw new UsernameNotFoundException("Identity must be provided as username@school_id");
        }

        int atIndex = loginInput.lastIndexOf("@");
        String username = loginInput.substring(0, atIndex);
        String schoolId = loginInput.substring(atIndex + 1);

        return loadUserByUsernameAndSchool(username, schoolId);
    }

    /**
     * Specialized lookup used by JwtAuthenticationFilter.
     * Ensures the student exists specifically within the school scope provided by the JWT.
     */
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsernameAndSchool(String username, String schoolId) throws UsernameNotFoundException {
        log.debug("Loading student [{}] for school [{}]", username, schoolId);

        Student student = studentRepository.findByUsernameAndSchoolId(username, schoolId)
                .orElseThrow(() -> {
                    log.error("Student not found: {} for school: {}", username, schoolId);
                    return new UsernameNotFoundException(
                            String.format("Student %s not found for school %s", username, schoolId));
                });

        // Returns our new SecurityStudent wrapper
        return new SecurityStudent(student);
    }
}