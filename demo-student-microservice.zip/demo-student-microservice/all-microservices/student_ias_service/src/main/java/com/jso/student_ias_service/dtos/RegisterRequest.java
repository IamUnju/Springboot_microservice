package com.jso.student_ias_service.dtos;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.Set;


public record RegisterRequest(
        @NotBlank(message = "Username/Registration Number is required")
        @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
        String username,

        @NotBlank(message = "Password is required")
        @Size(min = 8, message = "Password must be at least 8 characters long")
        String password,

        @NotBlank(message = "Email is required")
        @Email(message = "Please provide a valid email address")
        String email,

        @NotBlank(message = "Full Name is required")
        String fullName,

        @NotBlank(message = "School identifier is required")
        String schoolIdentifier,

        // Optional fields specifically for Student profiles
        String gradeLevel,

        // Roles to be assigned (used primarily by Admin registration)
        Set<String> roles
) {}