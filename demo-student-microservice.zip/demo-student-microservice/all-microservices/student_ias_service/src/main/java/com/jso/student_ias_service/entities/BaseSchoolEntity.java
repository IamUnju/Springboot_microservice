package com.jso.student_ias_service.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

@MappedSuperclass
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public abstract class BaseSchoolEntity {

    @Column(name = "school_id", nullable = false, updatable = false, length = 50)
    private String schoolId; // Matches the String identifier from JWT

    @CreatedDate
    @Column(name = "created_at", updatable = false)
    private Instant createdAt;

    @CreatedBy
    @Column(name = "created_by", updatable = false, length = 50)
    private String createdBy;

    @LastModifiedDate
    @Column(name = "last_modified_at")
    private Instant lastModifiedAt;

    @LastModifiedBy
    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @PrePersist
    public void onPrePersist() {
        // Force isolation by pulling the School ID from the SchoolContext
        if (this.schoolId == null && SchoolContext.getSchoolId() != null) {
            this.schoolId = SchoolContext.getSchoolId();
        }

        // Handle initial creation timestamp
        if (this.createdAt == null) {
            this.createdAt = Instant.now();
        }
    }
}