package com.jso.student_ias_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentIasServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentIasServiceApplication.class, args);
	}

}
