package com.jso.student_ias_service.controller;

import com.jso.student_ias_service.config.JwtService;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.interfaces.RSAPublicKey;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class JwksController {
    private final JwtService jwtService;

    @GetMapping("/.well-known/jwks.json")
    public Map<String, Object> getJwks() {
        try {

            RSAPublicKey publicKey = (RSAPublicKey) jwtService.getPublicKey();

            RSAKey jwk = new RSAKey.Builder(publicKey)
                    .keyID("jso-student-key-01")
                    .build();

            return new JWKSet(jwk).toJSONObject();

        } catch (Exception e) {
            throw new RuntimeException("Could not generate JWK Set", e);
        }
    }
}