package com.jso.student_ias_service.repo;

import com.jso.student_ias_service.entities.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Optional<Student> findByUsernameAndSchoolId(String username, String schoolId);
    Optional<Student> findByUsername(String username);
    Optional<Student> findByEmail(String email);
    Optional<Student> findBySecurity_PasswordResetToken(String token);
}