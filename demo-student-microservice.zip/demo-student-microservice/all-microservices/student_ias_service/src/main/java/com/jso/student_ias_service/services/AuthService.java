package com.jso.student_ias_service.services;

import com.jso.student_ias_service.config.JwtService;
import com.jso.student_ias_service.config.SecurityStudent;
import com.jso.student_ias_service.dtos.AuthRequest;
import com.jso.student_ias_service.dtos.AuthResponse;
import com.jso.student_ias_service.entities.EnrollmentStatus;
import com.jso.student_ias_service.entities.LoginAudit;
import com.jso.student_ias_service.entities.SchoolContext;
import com.jso.student_ias_service.entities.Student;
import com.jso.student_ias_service.repo.LoginAuditRepository;
import com.jso.student_ias_service.repo.StudentRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final StudentRepository studentRepository;
    private final LoginAuditRepository auditRepository;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final HttpServletRequest httpRequest;


    @Transactional
    public AuthResponse login(AuthRequest request) {
        String compositeIdentity = request.username() + "@" + request.schoolIdentifier();

        try {
            // 1. Authenticate via Spring Security (using the CustomUserDetailsService)
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(compositeIdentity, request.password())
            );

            SecurityStudent studentDetails = (SecurityStudent) authentication.getPrincipal();

            // 2. Validate Enrollment Status
            assert studentDetails != null;
            if (studentDetails.getStatus() != EnrollmentStatus.ACTIVE) {
                recordAudit(request, false, "ACCOUNT_INACTIVE");
                throw new RuntimeException("Account is " + studentDetails.getStatus());
            }

            // 3. Success logic: Update metadata and Audit
            updateLoginMetadata(request.username(), request.schoolIdentifier());
            recordAudit(request, true, null);

            log.info("Student {} successfully logged into school {}", request.username(), request.schoolIdentifier());

            return buildAuthResponse(
                    jwtService.generateAccessToken(studentDetails),
                    jwtService.generateRefreshToken(studentDetails),
                    studentDetails
            );

        } catch (BadCredentialsException e) {
            recordAudit(request, false, "INVALID_CREDENTIALS");
            throw new BadCredentialsException("Invalid registration number or password.");
        } catch (LockedException e) {
            recordAudit(request, false, "ACCOUNT_LOCKED");
            throw new LockedException("Your account is locked due to multiple failed attempts.");
        } catch (Exception e) {
            recordAudit(request, false, e.getMessage());
            log.error("Authentication error: ", e);
            throw e;
        }
    }

    @Transactional(readOnly = true)
    public AuthResponse refreshToken(String refreshToken) {
        String username = jwtService.extractUsername(refreshToken);
        String schoolId = jwtService.extractSchoolId(refreshToken);

        Student student = studentRepository.findByUsernameAndSchoolId(username, schoolId)
                .orElseThrow(() -> new RuntimeException("Student record no longer exists."));

        SecurityStudent studentDetails = new SecurityStudent(student);

        if (!jwtService.isTokenValid(refreshToken, studentDetails)) {
            throw new RuntimeException("Invalid or expired refresh token.");
        }

        String newAccessToken = jwtService.generateAccessToken(studentDetails);
        return buildAuthResponse(newAccessToken, refreshToken, studentDetails);
    }


    @Transactional
    public void changePassword(String oldPassword, String newPassword) {
        String username = Objects.requireNonNull(SecurityContextHolder.getContext().getAuthentication()).getName();

        // Context-aware lookup (schoolId is handled by SchoolContext)
        Student student = studentRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User session is invalid."));

        if (!passwordEncoder.matches(oldPassword, student.getSecurity().getPasswordHash())) {
            throw new BadCredentialsException("Current password does not match.");
        }

        student.getSecurity().setPasswordHash(passwordEncoder.encode(newPassword));
        studentRepository.save(student);
    }

    /**
     * PASSWORD RESET INITIATION
     */
    @Transactional
    public String initiatePasswordReset(String email) {
        Student student = studentRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("If account exists, instructions have been sent."));

        String resetToken = student.getSecurity().generateResetToken();
        studentRepository.save(student);

        log.info("Password reset initiated for student: {}", student.getUsername());
        return resetToken;
    }

    /**
     * PASSWORD RESET COMPLETION
     */
    @Transactional
    public void resetPassword(String token, String newPassword) {
        Student student = studentRepository.findBySecurity_PasswordResetToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid or expired reset token."));

        if (!student.getSecurity().matchesResetToken(token)) {
            throw new RuntimeException("Reset link has expired.");
        }

        student.getSecurity().setPasswordHash(passwordEncoder.encode(newPassword));
        student.getSecurity().clearResetToken();
        studentRepository.save(student);
    }

    // --- Private Helper Methods ---

    private void recordAudit(AuthRequest request, boolean success, String reason) {
        LoginAudit audit = LoginAudit.builder()
                .username(request.username())
                .schoolId(request.schoolIdentifier())
                .success(success)
                .failureReason(reason)
                .ipAddress(SchoolContext.getClientIp()) // Pulled from ThreadLocal
                .userAgent(httpRequest.getHeader("User-Agent"))
                .build();

        auditRepository.save(audit);
    }

    private void updateLoginMetadata(String username, String schoolId) {
        studentRepository.findByUsernameAndSchoolId(username, schoolId)
                .ifPresent(s -> {
                    s.getSecurity().recordSuccessfulLogin();
                    studentRepository.save(s);
                });
    }

    private AuthResponse buildAuthResponse(String access, String refresh, SecurityStudent student) {
        return AuthResponse.builder()
                .accessToken(access)
                .refreshToken(refresh)
                .username(student.getUsername())
                .schoolIdentifier(student.getSchoolId())
                .userId(student.getStudentId())
                .status(student.getStatus().name())
                .roles(student.getAuthorities().stream()
                        .map(GrantedAuthority::getAuthority)
                        .toList())
                .build();
    }
}