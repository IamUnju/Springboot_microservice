package com.jso.student_ias_service.entities;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity
@Table(
        name = "login_audits",
        indexes = {
                @Index(name = "idx_login_audit_username", columnList = "username"),
                @Index(name = "idx_login_audit_school", columnList = "school_id"),
                @Index(name = "idx_login_audit_time", columnList = "login_at")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50, updatable = false)
    private String username;

    @Column(name = "school_id", nullable = false, length = 50, updatable = false)
    private String schoolId; // Matches school_identifier

    @Column(nullable = false, updatable = false)
    private boolean success;

    @Column(name = "ip_address", length = 45, updatable = false)
    private String ipAddress;

    @Column(name = "user_agent", length = 512, updatable = false)
    private String userAgent;

    @Column(name = "login_at", nullable = false, updatable = false)
    private Instant loginAt;

    @Column(name = "failure_reason", length = 100, updatable = false)
    private String failureReason;

    @PrePersist
    protected void onCreate() {
        if (this.loginAt == null) {
            this.loginAt = Instant.now();
        }
        // Force sync with the global SchoolContext if not manually set
        if (this.schoolId == null) {
            this.schoolId = SchoolContext.getSchoolId();
        }
    }
}