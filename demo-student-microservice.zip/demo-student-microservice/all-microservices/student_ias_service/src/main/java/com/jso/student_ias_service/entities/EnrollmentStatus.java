package com.jso.student_ias_service.entities;

public enum EnrollmentStatus {
    ACTIVE,
    GRADUATED,
    DROPPED,
    SUSPENDED,
    INACTIVE
}