package com.jso.student_ias_service.repo;

import com.jso.student_ias_service.entities.LoginAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoginAuditRepository extends JpaRepository<LoginAudit, Long> {
    // Helpful for school admins to monitor security
    List<LoginAudit> findBySchoolIdOrderByLoginAtDesc(String schoolId);

    // Helpful for tracking suspicious activity on a specific student account
    List<LoginAudit> findByUsernameAndSchoolIdOrderByLoginAtDesc(String username, String schoolId);
}