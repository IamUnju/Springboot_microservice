package com.jso.student_ias_service.dtos;

import jakarta.validation.constraints.NotBlank;

public record AuthRequest(
        @NotBlank(message = "Username/Registration number is required")
        String username,

        @NotBlank(message = "Password is required")
        String password,

        @NotBlank(message = "School identifier is required")
        String schoolIdentifier
) {}