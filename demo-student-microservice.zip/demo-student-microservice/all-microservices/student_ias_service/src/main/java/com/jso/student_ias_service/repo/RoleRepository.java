package com.jso.student_ias_service.repo;

import com.jso.student_ias_service.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByNameAndSchoolId(String name, String schoolId);
    List<Role> findAllByNameInAndSchoolId(Set<String> names, String schoolId);
}