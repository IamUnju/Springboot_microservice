package com.jso.student_ias_service.controller;

import com.jso.student_ias_service.dtos.RegisterRequest;
import com.jso.student_ias_service.services.RegistrationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/registration")
@RequiredArgsConstructor
public class AdminRegistrationController {

    private final RegistrationService registrationService;

    /**
     * Allows a School Admin to create staff, teacher, or student accounts.
     * Route: POST /api/v1/admin/registration/create-user
     */
    @PostMapping("/create-user")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> registerByAdmin(@Valid @RequestBody RegisterRequest request) {
        registrationService.registerUserByAdmin(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Account successfully created by school administrator.");
    }


    @PostMapping("/create-high-level")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    public ResponseEntity<String> createHighLevelAdmin(@Valid @RequestBody RegisterRequest request) {
        // 1. Extract the role from the Set<String> inside the DTO
        String targetRole = request.roles().stream()
                .filter(role -> role.equals("ROLE_ADMIN") || role.equals("ROLE_SUPER_ADMIN"))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("A valid administrative role is required in the JSON body."));

        // 2. Delegate to Service
        registrationService.registerHighLevelAdmin(request, targetRole);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Success: Admin account created for " + request.username());
    }
}