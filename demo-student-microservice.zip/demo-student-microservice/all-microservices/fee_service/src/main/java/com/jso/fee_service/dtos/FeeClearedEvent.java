package com.jso.fee_service.dtos;

public record FeeClearedEvent(
        String studentId,
        String schoolId,
        Double amountPaid,
        long timestamp
) {}