package com.jso.fee_service.services;

import com.jso.fee_service.dtos.FeeClearedEvent;
import com.jso.fee_service.dtos.FeeResponse;
import com.jso.fee_service.dtos.PaymentRequest;
import com.jso.fee_service.entities.SchoolContext;
import com.jso.fee_service.entities.StudentFee;
import com.jso.fee_service.repo.StudentFeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class FeeService {

    private final StudentFeeRepository repository;
    private final KafkaTemplate<String, Object> kafkaTemplate;

    /**
     * SYNC: Used by Academic Service.
     * Uses the secure repository method that automatically filters by SchoolContext.
     */
    @Transactional(readOnly = true)
    public boolean getStudentFeeStatus(String studentId) {
        log.debug("Checking fee status for student: {} in school: {}", studentId, SchoolContext.getSchoolId());

        return repository.findByStudentIdInCurrentSchool(studentId)
                .map(StudentFee::isCleared)
                .orElse(false); // If no record, we assume not cleared
    }

    /**
     * ASYNC PRODUCER: Updates DB and notifies the system via Kafka.
     */
    @Transactional
    public FeeResponse processPayment(PaymentRequest request) {
        String studentId = request.studentId();
        String currentSchoolId = SchoolContext.getSchoolId();

        // Use the secure lookup
        StudentFee fee = repository.findByStudentIdInCurrentSchool(studentId)
                .orElseThrow(() -> new RuntimeException("DATA ERROR: No fee record exists for Student ID ["
                        + studentId + "] in School [" + currentSchoolId + "]"));

        fee.setPaidAmount(fee.getPaidAmount() + request.amount());

        if (fee.checkClearence() && !fee.isCleared()) {
            fee.setCleared(true);

            FeeClearedEvent event = new FeeClearedEvent(
                    studentId,
                    currentSchoolId,
                    request.amount(),
                    System.currentTimeMillis()
            );

            // Publish to Kafka (Verified running in Docker)
            kafkaTemplate.send("fee-cleared-topic", studentId, event);
            log.info("KAFKA: Published FeeClearedEvent for student: {}", studentId);
        }

        StudentFee updatedFee = repository.save(fee);
        log.info("DATABASE: Payment processed. New balance for {}: {}/{}",
                studentId, updatedFee.getPaidAmount(), updatedFee.getTotalAmount());

        return mapToResponse(updatedFee);
    }

    private FeeResponse mapToResponse(StudentFee fee) {
        return new FeeResponse(
                fee.getStudentId(),
                fee.getTotalAmount(),
                fee.getPaidAmount(),
                fee.isCleared()
        );
    }
}