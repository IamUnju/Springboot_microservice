package com.jso.fee_service.config;

import com.jso.fee_service.entities.SchoolContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.NonNull;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;

@Slf4j
@Component
public class ContextInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(
            HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull Object handler
    ) throws IOException {
        // 1. Log incoming request
        log.info("INTERCEPTOR: {} {}", request.getMethod(), request.getRequestURI());

        // 2. Security Check (Optional logging)
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated()) {
            log.debug("User: {} | Authorities: {}", auth.getName(), auth.getAuthorities());
        }

        // 3. Mandatory Multi-Tenancy Header Check
        String schoolId = request.getHeader("X-School-Id");

        if (schoolId == null || schoolId.trim().isEmpty()) {
            log.error("REJECTED: Missing 'X-School-Id' header for request to {}", request.getRequestURI());

            // Send a clean 400 Bad Request instead of letting the app crash with a NullPointerException later
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Multi-tenancy violation: X-School-Id header is required\"}");
            return false; // Stops the request from reaching the Controller
        }

        // 4. Success: Set the ThreadLocal Context
        log.info("CONTEXT SET: School ID = {}", schoolId);
        SchoolContext.setSchoolId(schoolId);

        return true;
    }

    @Override
    public void afterCompletion(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull Object handler, Exception ex) {
        // CRITICAL: Prevent memory leaks and cross-tenant data contamination
        log.trace("CONTEXT CLEAR: Cleaning up ThreadLocal");
        SchoolContext.clear();
    }
}