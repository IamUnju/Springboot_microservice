package com.jso.fee_service.repo;

import com.jso.fee_service.entities.StudentFee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentFeeRepository extends JpaRepository<StudentFee, Long> {

    /**
     * SECURE LOOKUP: Uses SpEL to automatically inject the schoolId from the ThreadLocal SchoolContext.
     * This ensures the query ALWAYS filters by the current school, even if the service layer is messy.
     */
    @Query("SELECT sf FROM StudentFee sf WHERE sf.studentId = :studentId " +
            "AND sf.schoolId = :#{T(com.jso.fee_service.entities.SchoolContext).getSchoolId()}")
    Optional<StudentFee> findByStudentIdInCurrentSchool(@Param("studentId") String studentId);

    /**
     * Standard method: Still useful if you need to pass the ID explicitly.
     */
    Optional<StudentFee> findByStudentIdAndSchoolId(String studentId, String schoolId);

    /**
     * Retrieves all fee records for the current school context automatically.
     */
    @Query("SELECT sf FROM StudentFee sf WHERE sf.schoolId = :#{T(com.jso.fee_service.entities.SchoolContext).getSchoolId()}")
    List<StudentFee> findAllInCurrentSchool();

    /**
     * Standard method for administrative tasks.
     */
    List<StudentFee> findAllBySchoolId(String schoolId);

    boolean existsByStudentIdAndSchoolId(String studentId, String schoolId);
}