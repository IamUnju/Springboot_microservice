package com.jso.fee_service.dtos;

public record PaymentRequest(String studentId, Double amount) {}