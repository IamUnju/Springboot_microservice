package com.jso.fee_service.controller;

import com.jso.fee_service.dtos.FeeResponse;
import com.jso.fee_service.dtos.PaymentRequest;
import com.jso.fee_service.entities.SchoolContext;
import com.jso.fee_service.services.FeeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/fees")
@RequiredArgsConstructor
public class FeeController {

    private final FeeService feeService;

    @GetMapping("/status/{studentId}")
    public boolean isFeeCleared(@PathVariable String studentId) {
        log.info("REST: Fee status check for student: {} [School: {}]",
                studentId, SchoolContext.getSchoolId());
        return feeService.getStudentFeeStatus(studentId);
    }

    @PostMapping("/payment")
    @PreAuthorize("hasAuthority('ROLE_SUPER_ADMIN')")
    public ResponseEntity<FeeResponse> processPayment(@Valid @RequestBody PaymentRequest request) {
        log.info("REST: Payment request for student: {} amount: {} [School: {}]",
                request.studentId(), request.amount(), SchoolContext.getSchoolId());

        FeeResponse response = feeService.processPayment(request);
        return ResponseEntity.ok(response);
    }
}