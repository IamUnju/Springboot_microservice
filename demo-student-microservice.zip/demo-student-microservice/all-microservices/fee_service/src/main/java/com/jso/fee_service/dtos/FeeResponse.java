package com.jso.fee_service.dtos;

public record FeeResponse(String studentId, Double totalAmount, Double paidAmount, boolean isCleared) {}