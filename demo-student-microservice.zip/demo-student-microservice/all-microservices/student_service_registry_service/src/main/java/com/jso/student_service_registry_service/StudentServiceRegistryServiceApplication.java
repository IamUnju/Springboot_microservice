package com.jso.student_service_registry_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class StudentServiceRegistryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServiceRegistryServiceApplication.class, args);
	}

}
