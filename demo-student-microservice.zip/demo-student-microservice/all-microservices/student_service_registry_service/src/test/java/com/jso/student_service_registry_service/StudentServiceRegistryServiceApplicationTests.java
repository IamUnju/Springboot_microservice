package com.jso.student_service_registry_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServiceRegistryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
