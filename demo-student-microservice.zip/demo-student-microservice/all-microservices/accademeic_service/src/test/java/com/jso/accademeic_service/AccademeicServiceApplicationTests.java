package com.jso.accademeic_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccademeicServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
