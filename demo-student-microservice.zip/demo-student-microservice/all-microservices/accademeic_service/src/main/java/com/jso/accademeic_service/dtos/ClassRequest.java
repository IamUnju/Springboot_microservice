package com.jso.accademeic_service.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ClassRequest(
        @NotBlank(message = "Class name is required")
        @Size(min = 3, max = 50)
        String name,

        @NotBlank(message = "Subject code is required")
        String subjectCode
) {}