package com.jso.accademeic_service.config; // or .services

import com.jso.accademeic_service.dtos.FeeClearedEvent;
import com.jso.accademeic_service.services.AcademicService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class FeeEventConsumer {

    private final AcademicService academicService;

    @KafkaListener(topics = "fee-cleared-topic", groupId = "academic-service-group")
    public void consumeFeeCleared(FeeClearedEvent event) {
        log.info("KAFKA CONSUMER: Received payment notice for student {}", event.studentId());

        try {
            // Trigger the service logic to update the local database
            academicService.markStudentAsCleared(event.studentId(), event.schoolId());
        } catch (Exception e) {
            log.error("Failed to process payment event: {}", e.getMessage());
        }
    }
}