package com.jso.accademeic_service.config;

import com.jso.accademeic_service.entities.SchoolContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class ContextInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String schoolId = request.getHeader("X-School-Id");
        String userId = request.getHeader("X-Student-Id");

        if (schoolId != null) SchoolContext.setSchoolId(schoolId);
        if (userId != null) SchoolContext.setUserId(userId);

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        SchoolContext.clear(); // Vital to prevent memory leaks in ThreadLocal
    }
}


