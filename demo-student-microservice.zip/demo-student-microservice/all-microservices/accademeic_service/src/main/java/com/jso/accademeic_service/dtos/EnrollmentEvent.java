package com.jso.accademeic_service.dtos;

import java.io.Serializable;

public record EnrollmentEvent(
        String studentId,    // java.lang.String
        Long classId,        // java.lang.Long (Changed from String)
        String schoolId,     // java.lang.String (Changed from Double)
        long timestamp
) implements Serializable {}