package com.jso.accademeic_service.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaConfig {
    @Bean
    public NewTopic enrollmentTopic() {
        return TopicBuilder.name("student-enrollments")
                .partitions(3) // High availability
                .replicas(1)
                .build();
    }
}