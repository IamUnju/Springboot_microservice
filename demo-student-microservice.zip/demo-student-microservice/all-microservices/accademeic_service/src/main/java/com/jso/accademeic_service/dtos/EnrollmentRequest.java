package com.jso.accademeic_service.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record EnrollmentRequest(
        @NotNull(message = "Class ID is required")
        Long classId,

        @NotBlank(message = "Student ID is required")
        String studentId
) {}