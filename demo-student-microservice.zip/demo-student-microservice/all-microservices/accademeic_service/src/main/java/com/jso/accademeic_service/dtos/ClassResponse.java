package com.jso.accademeic_service.dtos;

import lombok.Builder;
import java.util.Set;

@Builder
public record ClassResponse(
        Long id,
        String name,
        String subjectCode,
        Set<String> enrolledStudentIds
) {}