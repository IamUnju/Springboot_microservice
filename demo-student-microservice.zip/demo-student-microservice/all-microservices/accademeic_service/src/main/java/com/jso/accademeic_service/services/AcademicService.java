package com.jso.accademeic_service.services;

import com.jso.accademeic_service.dtos.*;
import com.jso.accademeic_service.entities.FeeClient;
import com.jso.accademeic_service.entities.SchoolClass;
import com.jso.accademeic_service.entities.SchoolContext;
import com.jso.accademeic_service.repo.SchoolClassRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;

@Slf4j
@Service
@RequiredArgsConstructor
public class AcademicService {

    private final SchoolClassRepository repository;
    private final FeeClient feeClient;
    private final KafkaTemplate<String, Object> kafkaTemplate;

    /**
     * LOGIC FOR CONSUMER: This is called by FeeEventConsumer when Kafka sends a message.
     */
    @Transactional
    public void markStudentAsCleared(String studentId, String schoolId) {
        log.info("ACADEMIC SERVICE: Processing fee clearance for student {} in school {}", studentId, schoolId);

        // FUTURE LOGIC:
        // Here you would find the Student entity in your local academic_db
        // and set student.setFeeStatus(CLEARED).
        // For now, we log the success.
    }

    @Transactional
    public ClassResponse createClass(ClassRequest request) {
        log.info("Creating new class: {} for school: {}", request.name(), SchoolContext.getSchoolId());

        SchoolClass schoolClass = SchoolClass.builder()
                .name(request.name())
                .subjectCode(request.subjectCode())
                .enrolledStudentIds(new HashSet<>())
                // No ID set here; Hibernate generates it
                .build();

        SchoolClass savedClass = repository.save(schoolClass);
        return mapToResponse(savedClass);
    }

    @Transactional
    public ClassResponse enrollStudent(EnrollmentRequest request) {
        String schoolId = SchoolContext.getSchoolId();
        String studentId = request.studentId();
        Long classId = request.classId();

        // 1. Sync Check (Feign) - The Gatekeeper
        if (!feeClient.isFeeCleared(studentId)) {
            log.warn("Enrollment blocked for student {} due to unpaid fees", studentId);
            throw new RuntimeException("Enrollment Blocked: Student has unpaid fees.");
        }

        // 2. Multi-tenant Context-Aware Lookup
        SchoolClass schoolClass = repository.findByIdAndSchoolId(classId, schoolId)
                .orElseThrow(() -> new RuntimeException("Class not found for your school context."));

        // 3. Update State
        schoolClass.getEnrolledStudentIds().add(studentId);
        repository.save(schoolClass);

        // 4. Async Notification (Producer)
        EnrollmentEvent event = new EnrollmentEvent(
                studentId,
                classId,
                schoolId,
                System.currentTimeMillis()
        );

        kafkaTemplate.send("student-enrollments", studentId, event);
        log.info("KAFKA SENT: Enrollment event for student {} in class {}", studentId, classId);

        return mapToResponse(schoolClass);
    }

    private ClassResponse mapToResponse(SchoolClass entity) {
        return ClassResponse.builder()
                .id(entity.getId())
                .name(entity.getName())
                .subjectCode(entity.getSubjectCode())
                .enrolledStudentIds(entity.getEnrolledStudentIds())
                .build();
    }
}