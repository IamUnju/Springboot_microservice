package com.jso.accademeic_service.entities;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "fee-service")
public interface FeeClient {

    @GetMapping("/api/v1/fees/status/{studentId}")
    @CircuitBreaker(name = "feeServiceCB", fallbackMethod = "feeFallback")
    boolean isFeeCleared(@PathVariable("studentId") String studentId);

    // Fallback method must have the same signature + Throwable
    default boolean feeFallback(String studentId, Throwable t) {
        // Log the reason (t.getMessage())
        // Professional approach: Deny enrollment if we can't verify fee status
        return false;
    }
}