package com.jso.accademeic_service.repo;

import com.jso.accademeic_service.entities.SchoolClass;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SchoolClassRepository extends JpaRepository<SchoolClass, Long> {
    // Crucial for security: always find by both ID and the current School Context
    Optional<SchoolClass> findByIdAndSchoolId(Long id, String schoolId);
}