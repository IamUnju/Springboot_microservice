package com.jso.accademeic_service.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "school_classes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder // Required to work with BaseSchoolEntity's SuperBuilder
public class SchoolClass extends BaseSchoolEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String subjectCode;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "class_enrollments", joinColumns = @JoinColumn(name = "class_id"))
    @Column(name = "student_id")
    private Set<String> enrolledStudentIds = new HashSet<>();
}