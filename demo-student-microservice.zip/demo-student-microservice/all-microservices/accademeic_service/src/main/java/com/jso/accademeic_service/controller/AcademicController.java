package com.jso.accademeic_service.controller;

import com.jso.accademeic_service.dtos.ClassRequest;
import com.jso.accademeic_service.dtos.ClassResponse;
import com.jso.accademeic_service.dtos.EnrollmentRequest;
import com.jso.accademeic_service.services.AcademicService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/academic")
@RequiredArgsConstructor
public class AcademicController {

    private final AcademicService academicService;

    @PostMapping("/classes")
    @PreAuthorize("hasAuthority('ROLE_SUPER_ADMIN')")
    public ResponseEntity<ClassResponse> createClass(@Valid @RequestBody ClassRequest request) {
        return new ResponseEntity<>(academicService.createClass(request), HttpStatus.CREATED);
    }

    /**
     * Payload example: { "classId": 1, "studentId": "STUD-001" }
     * Note: classId in JSON will be a number (1), which Java maps to Long.
     */
    @PostMapping("/enroll")
    @PreAuthorize("hasAuthority('ROLE_SUPER_ADMIN')")
    public ResponseEntity<ClassResponse> enroll(@Valid @RequestBody EnrollmentRequest request) {
        // Validation check for fee status and multi-tenancy happens in the service layer
        return ResponseEntity.ok(academicService.enrollStudent(request));
    }
}