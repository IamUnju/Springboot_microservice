package com.jso.accademeic_service.entities;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SchoolContext {

    private static final ThreadLocal<String> CURRENT_SCHOOL_ID = new ThreadLocal<>();
    private static final ThreadLocal<String> CURRENT_USER_ID = new ThreadLocal<>();
    private static final ThreadLocal<String> CLIENT_IP = new ThreadLocal<>();

    public static void setSchoolId(String schoolId) {
        log.trace("Setting school context to: {}", schoolId);
        CURRENT_SCHOOL_ID.set(schoolId);
    }

    public static String getSchoolId() {
        return CURRENT_SCHOOL_ID.get();
    }

    public static void setUserId(String userId) {
        log.trace("Setting user context to: {}", userId);
        CURRENT_USER_ID.set(userId);
    }

    public static String getUserId() {
        return CURRENT_USER_ID.get();
    }

    public static void setClientIp(String ip) {
        CLIENT_IP.set(ip);
    }

    public static String getClientIp() {
        return CLIENT_IP.get();
    }

    public static void clear() {
        log.trace("Clearing all school thread-local contexts");
        CURRENT_SCHOOL_ID.remove();
        CURRENT_USER_ID.remove();
        CLIENT_IP.remove();
    }
}