package com.jso.accademeic_service.dtos;

public record FeeClearedEvent(
        String studentId,
        String schoolId,
        Double amount,
        Long timestamp
) {}