package com.jso.student_api_gate_way_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentApiGateWayServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentApiGateWayServiceApplication.class, args);
	}

}
