package com.jso.student_api_gate_way_service.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.function.HandlerFilterFunction;
import org.springframework.web.servlet.function.HandlerFunction;
import org.springframework.web.servlet.function.ServerRequest;
import org.springframework.web.servlet.function.ServerResponse;

@Component
public class SchoolHeaderFilter implements HandlerFilterFunction<ServerResponse, ServerResponse> {

    @Override
    public ServerResponse filter(ServerRequest request, HandlerFunction<ServerResponse> next) throws Exception {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null && auth.getPrincipal() instanceof Jwt jwt) {
            String schoolId = jwt.getClaimAsString("school_id");
            String userId = jwt.getClaimAsString("userId");

            // Inject headers for downstream microservices
            ServerRequest modifiedRequest = ServerRequest.from(request)
                    .header("X-School-Id", schoolId != null ? schoolId : "")
                    .header("X-Student-Id", userId != null ? userId : "")
                    .build();

            return next.handle(modifiedRequest);
        }

        return next.handle(request);
    }
}