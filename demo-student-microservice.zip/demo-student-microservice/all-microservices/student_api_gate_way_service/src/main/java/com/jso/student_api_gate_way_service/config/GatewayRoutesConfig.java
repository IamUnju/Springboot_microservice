package com.jso.student_api_gate_way_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;

import static org.springframework.cloud.gateway.server.mvc.filter.LoadBalancerFilterFunctions.lb;
import static org.springframework.cloud.gateway.server.mvc.handler.GatewayRouterFunctions.route;
import static org.springframework.cloud.gateway.server.mvc.handler.HandlerFunctions.http;
import static org.springframework.cloud.gateway.server.mvc.predicate.GatewayRequestPredicates.path;

@Configuration
public class GatewayRoutesConfig {

    @Bean
    public RouterFunction<ServerResponse> gatewayRoutes(SchoolHeaderFilter schoolFilter) {
        return route()
                // --- 1. Academic Service Route ---
                .route(path("/api/v1/academic/**"), http())
                .filter(lb("academic-service"))
                .filter(schoolFilter)

                // --- 2. Auth Service Route ---
                .route(path("/api/v1/auth/**"), http())
                .filter(lb("student-ias-service"))
                .filter(schoolFilter)

                // --- 3. Fee Service Route ---
                .route(path("/api/v1/fees/**"), http())
                .filter(lb("fee-service"))
                .filter(schoolFilter)

                .build();
    }
}