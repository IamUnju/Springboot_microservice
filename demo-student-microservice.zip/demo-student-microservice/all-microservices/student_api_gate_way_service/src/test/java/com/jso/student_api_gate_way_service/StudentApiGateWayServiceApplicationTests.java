package com.jso.student_api_gate_way_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentApiGateWayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
